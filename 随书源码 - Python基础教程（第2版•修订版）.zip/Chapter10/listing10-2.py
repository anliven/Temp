# hello2.py
def hello():
    print "Hello, world!"