import wx
app = wx.App()
win = wx.Frame(None)
win.Show()
app.MainLoop()