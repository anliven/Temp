for line in open(filename):
    process(line)