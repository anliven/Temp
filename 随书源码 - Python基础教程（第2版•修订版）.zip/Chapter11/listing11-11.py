import fileinput
for line in fileinput.input(filename):
    process(line)