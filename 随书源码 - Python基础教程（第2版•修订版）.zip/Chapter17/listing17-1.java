public class JythonTest {

   public void greeting() {
      System.out.println("Hello, world!");
   }

}